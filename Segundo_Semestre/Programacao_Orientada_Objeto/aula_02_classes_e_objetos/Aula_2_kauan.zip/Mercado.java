import java.util.Scanner;
public class Mercado
{
    public static void main(String arg[]){
        Scanner teclado = new Scanner(System.in);
        Produto prod1 = new Produto();
        Produto prod2 = new Produto();
        
        prod1.lerDados();
        System.out.println("");
        prod2.lerDados();
        
        prod1.mostrarDados();
        System.out.println("");
        prod2.mostrarDados();

    }
}
