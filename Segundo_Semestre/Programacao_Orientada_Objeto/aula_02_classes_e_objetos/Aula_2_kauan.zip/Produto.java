import java.util.Scanner;
class Produto
{
    int codigo;
    String nome;
    int qtd;
    private double preco;
    
    
    void setaPreco(double p){
        if (p>0)
            preco = p;
    }
    
    double retornaPreco(){
        return preco;
    }
    
    void lerDados(){
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Digite o codigo: ");
        codigo = teclado.nextInt();
        
        teclado.nextLine();
        System.out.print("Digite o nome: ");
        nome = teclado.nextLine();
                
        System.out.print("Digite o quantidade: ");
        qtd = teclado.nextInt();
        
        System.out.print("Digite o valor do produto: ");
        setaPreco(teclado.nextDouble());
    }

    
    void mostrarDados(){
        System.out.print("O código do " + nome + "é" + codigo);
        System.out.print("O nome do produto é: " + nome);
        System.out.print("A quantidade de " + nome + " em estoque é " + qtd);
        System.out.print("O preço do " + nome + " é R$" + preco);
    }
}
