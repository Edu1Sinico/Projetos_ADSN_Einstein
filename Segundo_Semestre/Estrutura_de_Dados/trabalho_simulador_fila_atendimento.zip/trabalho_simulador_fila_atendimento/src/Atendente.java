
public class Atendente extends Pessoa {

    private int disponivel; // 1 - disponivel | 0 - ocupado

    public Atendente(String nome) {
        super(nome);
        this.disponivel = 1;
    }

    public int getDisponivel() {
        return disponivel;
    }

    public void setDisponivel(int disponivel) {
        this.disponivel = disponivel;
    }
}
