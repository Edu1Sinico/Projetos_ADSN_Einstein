package com.tadseinstein.calcgasapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CalculadoraActivity : AppCompatActivity() {

    private lateinit var editNumeroUm: EditText
    private lateinit var editNumeroDois: EditText
    private lateinit var textResultado: TextView

    private lateinit var buttonSomar: Button
    private lateinit var buttonSubtrair: Button
    private lateinit var buttonMultiplicar: Button
    private lateinit var buttonDividir: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)

        editNumeroUm = findViewById(R.id.edit_numero_um)
        editNumeroDois = findViewById(R.id.edit_numero_dois)
        textResultado = findViewById(R.id.text_resultado)

        buttonSomar = findViewById(R.id.button_somar)
        buttonSubtrair = findViewById(R.id.button_subtrair)
        buttonMultiplicar = findViewById(R.id.button_multiplicar)
        buttonDividir = findViewById(R.id.button_dividir)

        buttonSomar.setOnClickListener {
            calcular("+")
        }

        buttonSubtrair.setOnClickListener {
            calcular("-")
        }

        buttonMultiplicar.setOnClickListener {
            calcular("*")
        }

        buttonDividir.setOnClickListener {
            calcular("/")
        }
    }

    private fun calcular(operacao: String) {
        val numeroUmTexto = editNumeroUm.text.toString()
        val numeroDoisTexto = editNumeroDois.text.toString()

        if (numeroUmTexto.isEmpty() || numeroDoisTexto.isEmpty()) {
            Toast.makeText(this, "Informe os dois números!", Toast.LENGTH_SHORT).show()
            return
        }

        val numeroUm = numeroUmTexto.toDouble()
        val numeroDois = numeroDoisTexto.toDouble()

        val resultado = when (operacao) {
            "+" -> numeroUm + numeroDois
            "-" -> numeroUm - numeroDois
            "*" -> numeroUm * numeroDois
            "/" -> {
                if (numeroDois == 0.0) {
                    Toast.makeText(this, "Não é possível dividir por zero!", Toast.LENGTH_SHORT).show()
                    return
                }
                numeroUm / numeroDois
            }
            else -> 0.0
        }

        textResultado.text = resultado.toString()
    }
}