package com.tadseinstein.calcgasapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MenuActivity : AppCompatActivity() {

    private lateinit var buttonCombustivel: Button
    private lateinit var buttonCalculadora: Button
    private lateinit var buttonSair: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        buttonCombustivel = findViewById(R.id.button_combustivel)
        buttonCalculadora = findViewById(R.id.button_calculadora)
        buttonSair = findViewById(R.id.button_sair)

        buttonCombustivel.setOnClickListener {
            abrirCombustivel()
        }

        buttonCalculadora.setOnClickListener {
            abrirCalculadora()
        }

        buttonSair.setOnClickListener {
            fecharAplicativo()
        }
    }

    private fun abrirCombustivel() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun abrirCalculadora() {
        val intent = Intent(this, CalculadoraActivity::class.java)
        startActivity(intent)
    }

    private fun fecharAplicativo() {
        finishAffinity()
    }
}