package com.tadseinstein.calcgasapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var editUser: EditText
    private lateinit var editSenha: EditText
    private lateinit var buttonLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        editUser = findViewById(R.id.edit_user)
        editSenha = findViewById(R.id.edit_senha)
        buttonLogin = findViewById(R.id.button_login)

        buttonLogin.setOnClickListener {
            realizarLogin()
        }
    }

    private fun realizarLogin() {
        val usuario = editUser.text.toString().trim()
        val senha = editSenha.text.toString().trim()

        if (usuario.isEmpty()) {
            editUser.error = "Informe o usuário"
            editUser.requestFocus()
            return
        }

        if (senha.isEmpty()) {
            editSenha.error = "Informe a senha"
            editSenha.requestFocus()
            return
        }

        if (usuario == "admin" && senha == "123") {
            Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this, "Usuário ou senha inválidos!", Toast.LENGTH_SHORT).show()
        }
    }
}