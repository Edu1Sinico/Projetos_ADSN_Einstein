<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB', 'db_primeiro_banco');
// A função "define" cria uma variável passando um valor para a mesma

$charset = 'utf8';
$conn = mysqli_connect(HOST, USER, PASS, DB) or die('Erro de conexão.');
// A função "mysqli_connect" realiza a conexão com o banco de dados ou "die" se ocorrer algum erro.
