<?php
// A função http_build_query gera uma string de consulta codificada em URL a partir de um array
$postdata = http_build_query(
    array(
        'api_token' => 'TokenTeste'
    )
);

/*Neste processo criamos um array para armazenar o
cabeçalho do nosso html (header), definir o tipo de envio
(POST), e carregar seu conteúdo (content).*/
$opts = array(
    'http' =>
    array(
        'method' => 'POST',
        'header' => 'Content-Type: application/x-www-form-urlencoded',
        'content' => $postdata
    )
);

// Recebe uma array associativa e cria um contexto de fluxo baseado nesse array
$context = stream_context_create($opts);

// Pega o conteúdo de um arquivo e armazena dentro de uma variável. (Recebe em formato JSON)
$result = file_get_contents('http://localhost/primeiroprojeto/APIListaPessoas.php', false, $context);

$jsonObj = json_decode($result);

// Exibe o resultado da busca das pessoas na tela
// foreach ($jsonObj as $pessoa) {
//     echo "$pessoa->nome - $pessoa->idade anos<br>";
// }

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Primeiro Front-End</title>
</head>

<body>
    <h1>Lista de Pessoas</h1>
    <table class="table" border="1" style="font-size: 16px">
        <tr>
            <th style="text-align: center; width: 50%">Nome</th>
            <th style="text-align: center; width: 20%">Idade</th>
        </tr>
        <?php
        foreach ($jsonObj as $pessoa) {
            echo "<tr>";
            echo "<td style='text-align: left; width: 50%'> $pessoa->nome </td>";
            echo "<td style='text-align: left; width: 20%'> $pessoa->idade anos </td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>

</html>