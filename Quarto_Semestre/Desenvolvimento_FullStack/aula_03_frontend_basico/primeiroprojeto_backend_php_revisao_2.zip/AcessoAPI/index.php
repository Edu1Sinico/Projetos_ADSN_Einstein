<?php
    echo "Olá, mundo!";
?>