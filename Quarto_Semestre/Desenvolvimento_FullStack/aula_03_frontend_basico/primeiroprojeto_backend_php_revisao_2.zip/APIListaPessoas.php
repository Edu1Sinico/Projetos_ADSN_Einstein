<?php
// Cabeçalho informando que é um JSON
header('Content-Type: application/json');

// Utilizando somente o método "POST" do HTTP
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Definimndo um toke para nossa API
    $api_token = $_POST['api_token'];
    if ($api_token == 'TokenTeste') {


        // Conexão com o Banco de Dados
        require_once('dbConnect.php');

        // Define a coleção na nossa conexão
        mysqli_set_charset($conn, $charset);

        $query = 'SELECT id,nome,idade FROM pessoas';

        // Preparando a consulta para o banco de dados
        $stmt = mysqli_prepare($conn, $query);

        // Executa e armazena a query na memória
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        // Associa os campos da query a variáveis aqui do PHP
        mysqli_stmt_bind_result($stmt, $id, $nome, $idade);

        // Apenas para teste de funcionamento, vamos dar uma dump na variável
        // var_dump($stmt);

        $response = array(); // Criando uma array para carregar os dados da tabela

        // Carrega os dados em um array
        if (mysqli_stmt_num_rows($stmt) > 0) { // Checa se existe registros na tabela

            // Pega cada um dos registros e coloca nas variáveis associadas no comando "mysqli_stmt_bind_result"
            while (mysqli_stmt_fetch($stmt)) {
                // Coloca o conteúdo dos campos no array de nome $response
                array_push($response, array(
                    "id" => $id,
                    "nome" => $nome,
                    "idade" => $idade
                ));
            }
        }

        // Transforma o array em JSON e envia para o navegador
        echo json_encode($response);
    } else {
        // Caso ele não reconheça o token, ele retornará um JSON com "false"
        $response['auth_token'] = false;
        echo json_encode($response);
    }
}
