<?php
    // ============================================================
    //  ARQUIVO DE AUTENTICACAO (BackEnd)
    // ============================================================
    //  Este arquivo fornece as funcoes para:
    //  1. Gerar tokens JWT (usado no login)
    //  2. Validar tokens JWT (usado em todas as APIs protegidas)
    //  3. Configurar headers CORS (permite chamadas do FrontEnd)
    //
    //  Utiliza a biblioteca firebase/php-jwt (padrao da industria)
    // ============================================================

    // Inclui o autoloader que carrega as classes do firebase/php-jwt
    require_once(__DIR__ . '/autoload.php');
    require_once(__DIR__ . '/Config.php');

    // Importa as classes do Firebase JWT
    use Firebase\JWT\JWT;
    use Firebase\JWT\Key;

    /**
     * Gera um token JWT para o usuario informado.
     *
     * Como funciona por baixo dos panos:
     * 1. Monta um payload (array com dados do usuario + expiracao)
     * 2. JWT::encode() cria: HEADER (algoritmo) + PAYLOAD (dados) + SIGNATURE (assinatura)
     * 3. A assinatura garante que ninguem falsificou os dados
     *
     * @param string $usuario Nome do usuario
     * @return string Token JWT no formato: xxxxx.yyyyy.zzzzz
     */
    function gerarToken(string $usuario): string
    {
        global $jwtSecret, $jwtAlgorithm, $jwtExpiresIn;

        // Monta o payload (dados que vao dentro do token)
        $payload = [
            'iss'     => 'sistema-escolar',    // Emissor do token
            'sub'     => $usuario,              // Suario (subject)
            'usuario' => $usuario,              // Nome do usuario (custom claim)
            'iat'     => time(),                // Data de criacao (issued at)
            'exp'     => time() + $jwtExpiresIn // Data de expiracao
        ];

        // Gera o token usando a biblioteca firebase/php-jwt
        // Para encode(), a chave vai como string (HMAC usa chave simetrica)
        return JWT::encode($payload, $jwtSecret, $jwtAlgorithm);
    }

    /**
     * Valida o token JWT enviado no header Authorization.
     * Se invalido ou ausente, retorna erro 401 e encerra a execucao.
     *
     * Como funciona por baixo dos panos:
     * 1. Extrai o token do header HTTP "Authorization: Bearer xxxxx.yyyyy.zzzzz"
     * 2. JWT::decode() verifica a assinatura com a chave secreta
     * 3. Se a assinatura estiver errada -> excecao SignatureInvalidException
     * 4. Se o token expirou -> excecao ExpiredException
     * 5. Se tudo ok -> retorna os dados do payload
     *
     * @return array Payload do token (contendo 'usuario', 'exp', etc.)
     */
    function validarToken(): array
    {
        global $jwtSecret, $jwtAlgorithm;

        // Habilita CORS para permitir chamadas do FrontEnd
        configurarCORS();

        // Busca o header Authorization
        // O Apache muitas vezes nao coloca em $_SERVER, entao usamos getallheaders() como fallback
        $authHeader = null;
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
        } else {
            $headers = getallheaders();
            if (isset($headers['Authorization'])) {
                $authHeader = $headers['Authorization'];
            }
        }

        if (!$authHeader) {
            header('Content-Type: application/json');
            http_response_code(401);
            echo json_encode([
                'erro' => 'Token de autenticacao nao fornecido',
                'codigo' => 'TOKEN_AUSENTE'
            ]);
            exit;
        }

        // Extrai o token do header (formato: "Bearer <token>")
        $parts = explode(' ', $authHeader);
        if (count($parts) !== 2 || $parts[0] !== 'Bearer') {
            header('Content-Type: application/json');
            http_response_code(401);
            echo json_encode([
                'erro' => 'Formato do token invalido. Use: Bearer <token>',
                'codigo' => 'TOKEN_FORMATO_INVALIDO'
            ]);
            exit;
        }

        $token = $parts[1];

        try {
            // Decodifica e valida o token usando firebase/php-jwt
            // JWT::decode() faz:
            //   1. Verifica a assinatura HMAC-SHA256
            //   2. Verifica se o token nao expirou (claim 'exp')
            //   3. Verifica se ja pode ser usado (claim 'nbf' se existir)
            //   4. Retorna o payload como objeto stdClass
            $payload = JWT::decode($token, new Key($jwtSecret, $jwtAlgorithm));

            // Converte stdClass para array para manter compatibilidade
            return (array) $payload;

        } catch (\Firebase\JWT\ExpiredException $e) {
            // Token valido mas expirado
            header('Content-Type: application/json');
            http_response_code(401);
            echo json_encode([
                'erro' => 'Token expirado. Faca login novamente.',
                'codigo' => 'TOKEN_EXPIRADO'
            ]);
            exit;

        } catch (\Firebase\JWT\SignatureInvalidException $e) {
            // Token com assinatura invalida (alguem tentou falsificar)
            header('Content-Type: application/json');
            http_response_code(401);
            echo json_encode([
                'erro' => 'Token invalido: assinatura incorreta',
                'codigo' => 'TOKEN_INVALIDO'
            ]);
            exit;

        } catch (\Exception $e) {
            // Qualquer outro erro
            header('Content-Type: application/json');
            http_response_code(401);
            echo json_encode([
                'erro' => 'Token invalido: ' . $e->getMessage(),
                'codigo' => 'TOKEN_ERRO'
            ]);
            exit;
        }
    }

    /**
     * Configura os headers CORS (Cross-Origin Resource Sharing).
     */
    function configurarCORS(): void
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }
?>
