<?php
    // ============================================================
    //  API: ADICIONAR CURSO
    // ============================================================
    //  Insere um novo curso no banco de dados.
    //  Protegida por JWT - necessario token valido.
    //
    //  PARAMETROS: nome (via POST)
    // ============================================================

    // Valida o token JWT
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco
    require_once(__DIR__ . '/dbConnect.php');

    // Verifica se o parametro 'nome' foi enviado
    if (empty($_POST['nome'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Parametro obrigatorio: nome']);
        mysqli_close($conn);
        exit;
    }

    $nome = $_POST['nome'];

    // Prepara a query com placeholder '?'
    // 's' = string (indica que o parametro e uma string)
    $query = 'INSERT INTO cursos (nome) VALUES (?)';
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 's', $nome);

    // Executa a insercao
    $result = mysqli_stmt_execute($stmt);

    $response = [];

    if ($result) {
        // Retorna true se alguma linha foi afetada
        $response['incluiu'] = (mysqli_affected_rows($conn) > 0);
    } else {
        http_response_code(500);
        $response['erro'] = 'Erro na execucao do insert';
    }

    mysqli_close($conn);
    echo json_encode($response);
?>
