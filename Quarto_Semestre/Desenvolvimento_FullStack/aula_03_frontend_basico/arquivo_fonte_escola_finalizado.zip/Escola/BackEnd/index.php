<?php
    // ============================================================
    //  INDEX DO BACKEND - Verificacao de API
    // ============================================================
    //  Este arquivo verifica se a API esta funcionando.
    // ============================================================

    header('Content-Type: application/json');

    echo json_encode([
        'status'    => 'online',
        'mensagem'  => 'API do Sistema Escolar funcionando',
        'endpoints' => [
            'login'            => 'APILogin.php',
            'cursos_listar'    => 'APICursosListaTodos.php',
            'cursos_por_id'    => 'APICursosListaporID.php',
            'cursos_adicionar' => 'APICursosAdiciona.php',
            'cursos_alterar'   => 'APICursosAltera.php',
            'cursos_deletar'   => 'APICursosDeleta.php',
            'classes_listar'   => 'APIClassesListaTodos.php',
            'classes_por_id'   => 'APIClassesListaporID.php',
            'classes_adicionar'=> 'APIClassesAdiciona.php',
            'classes_alterar'  => 'APIClassesAltera.php',
            'classes_deletar'  => 'APIClassesDeleta.php'
        ]
    ]);
?>
