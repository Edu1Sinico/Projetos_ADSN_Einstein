<?php
    // ============================================================
    //  API: ADICIONAR CLASSE
    // ============================================================
    //  Insere uma nova classe no banco de dados.
    //  Protegida por JWT - necessario token valido.
    //
    //  PARAMETROS: nome, idcurso (via POST)
    // ============================================================

    // Valida o token JWT
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco
    require_once(__DIR__ . '/dbConnect.php');

    // Verifica se os parametros foram enviados
    if (empty($_POST['nome']) || empty($_POST['idcurso'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Parametros obrigatorios: nome e idcurso']);
        mysqli_close($conn);
        exit;
    }

    $nome     = $_POST['nome'];
    $id_curso = (int) $_POST['idcurso'];

    // Prepara a query com placeholders '?'
    // 'si' = string (nome) e integer (idcurso)
    $query = 'INSERT INTO classes (nome, curso_id) VALUES (?, ?)';
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'si', $nome, $id_curso);

    // Executa a insercao
    $result = mysqli_stmt_execute($stmt);

    $response = [];

    if ($result) {
        $response['incluiu'] = (mysqli_affected_rows($conn) > 0);
    } else {
        http_response_code(500);
        $response['erro'] = 'Erro na execucao do insert';
    }

    mysqli_close($conn);
    echo json_encode($response);
?>
