<?php
/**
 * Autoloader simples para o projeto (substitui o autoload do Composer).
 * Mapeia namespaces para diretorios do projeto.
 *
 * Firebase\JWT\* -> vendor/firebase/php-jwt/src/*
 */
spl_autoload_register(function ($class) {
    $prefix = 'Firebase\\JWT\\';
    $baseDir = __DIR__ . '/vendor/firebase/php-jwt/src/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});
