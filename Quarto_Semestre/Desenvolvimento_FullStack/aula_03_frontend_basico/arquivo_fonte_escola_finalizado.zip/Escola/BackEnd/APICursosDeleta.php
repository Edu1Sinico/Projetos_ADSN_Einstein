<?php
    // ============================================================
    //  API: DELETAR CURSO
    // ============================================================
    //  Remove um curso do banco de dados.
    //  Protegida por JWT - necessario token valido.
    //
    //  PARAMETROS: id (via POST)
    // ============================================================

    // Valida o token JWT
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco
    require_once(__DIR__ . '/dbConnect.php');

    // Verifica se o parametro 'id' foi enviado
    if (empty($_POST['id'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Parametro obrigatorio: id']);
        mysqli_close($conn);
        exit;
    }

    $id = (int) $_POST['id'];

    // Prepara a query com placeholder '?'
    // 'i' = integer
    $query = 'DELETE FROM cursos WHERE id = ?';
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $id);

    // Executa a exclusao
    $result = mysqli_stmt_execute($stmt);

    $response = [];

    if ($result) {
        $response['apagado'] = (mysqli_affected_rows($conn) > 0);
    } else {
        http_response_code(500);
        $response['erro'] = 'Erro na execucao do delete';
    }

    mysqli_close($conn);
    echo json_encode($response);
?>
