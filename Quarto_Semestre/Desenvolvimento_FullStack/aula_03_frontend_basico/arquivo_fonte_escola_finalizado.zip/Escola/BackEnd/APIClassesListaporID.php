<?php
    // ============================================================
    //  API: LISTAR CLASSE POR ID
    // ============================================================
    //  Retorna uma classe especifica com dados do curso.
    //  Protegida por JWT - necessario token valido.
    //
    //  PARAMETROS: id (via POST)
    // ============================================================

    // Valida o token JWT
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco
    require_once(__DIR__ . '/dbConnect.php');

    // Verifica se o parametro 'id' foi enviado
    if (empty($_POST['id'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Parametro obrigatorio: id']);
        mysqli_close($conn);
        exit;
    }

    $idClasse = (int) $_POST['id'];

    // Query com JOIN para trazer dados do curso
    $query = 'SELECT classes.id,
                     classes.nome,
                     cursos.id AS curso_id,
                     cursos.nome AS curso
              FROM classes
              INNER JOIN cursos ON classes.curso_id = cursos.id
              WHERE classes.id = ?';

    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $idClasse);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    mysqli_stmt_bind_result($stmt, $id, $nome, $curso_id, $curso);

    $response = [];

    if (mysqli_stmt_num_rows($stmt) > 0) {
        while (mysqli_stmt_fetch($stmt)) {
            $response[] = [
                'id'        => $id,
                'nome'      => $nome,
                'curso_id'  => $curso_id,
                'curso'     => $curso
            ];
        }
    } else {
        $response['warning'] = 'Registro nao encontrado';
    }

    mysqli_close($conn);
    echo json_encode($response);
?>
