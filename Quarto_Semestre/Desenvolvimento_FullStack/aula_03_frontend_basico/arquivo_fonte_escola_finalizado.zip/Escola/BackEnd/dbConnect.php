<?php
    // ============================================================
    //  CONEXAO COM O BANCO DE DADOS (MySQL via MySQLi)
    // ============================================================
    //  Este arquivo cria a conexao com o banco e configura o
    //  charset para garantir que acentos funcionem corretamente.
    // ============================================================

    define('HOST', 'localhost');
    define('USER', 'root');
    define('PASS', '');
    define('DB',   'escoladb');

    // Conecta ao banco de dados
    // mysqli_connect(host, usuario, senha, banco)
    $conn = mysqli_connect(HOST, USER, PASS, DB);

    // Verifica se a conexao foi bem-sucedida
    if (!$conn) {
        // Se falhar, retorna erro em formato JSON e encerra
        header('Content-Type: application/json');
        echo json_encode(['erro' => 'Erro de conexao com o banco: ' . mysqli_connect_error()]);
        exit;
    }

    // Configura o charset da conexao para UTF-8
    // Isso garante que acentos e caracteres especiais funcionem
    mysqli_set_charset($conn, 'utf8');
?>
