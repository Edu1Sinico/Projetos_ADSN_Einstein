<?php
    // ============================================================
    //  API: ALTERAR CURSO
    // ============================================================
    //  Altera o nome de um curso existente.
    //  Protegida por JWT - necessario token valido.
    //
    //  PARAMETROS: id, nome (via POST)
    // ============================================================

    // Valida o token JWT
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco
    require_once(__DIR__ . '/dbConnect.php');

    // Verifica se os parametros foram enviados
    if (empty($_POST['id']) || empty($_POST['nome'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Parametros obrigatorios: id e nome']);
        mysqli_close($conn);
        exit;
    }

    $id   = (int) $_POST['id'];
    $nome = $_POST['nome'];

    // Prepara a query com placeholders '?'
    // 'si' = string primeiro, integer depois (ordem dos parametros)
    $query = 'UPDATE cursos SET nome = ? WHERE id = ?';
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'si', $nome, $id);

    // Executa a atualizacao
    $result = mysqli_stmt_execute($stmt);

    $response = [];

    if ($result) {
        $response['alterou'] = (mysqli_affected_rows($conn) > 0);
    } else {
        http_response_code(500);
        $response['erro'] = 'Erro na execucao do update';
    }

    mysqli_close($conn);
    echo json_encode($response);
?>
