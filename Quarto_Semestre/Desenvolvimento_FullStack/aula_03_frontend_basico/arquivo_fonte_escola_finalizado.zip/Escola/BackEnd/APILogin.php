<?php
    // ============================================================
    //  API DE LOGIN - Gera Token JWT
    // ============================================================
    //  Recebe usuario e senha, verifica no BANCO DE DADOS
    //  e retorna um token JWT se as credenciais estiverem corretas.
    //
    //  METODO: POST
    //  PARAMETROS: usuario, senha
    //  RETORNO: { "token": "...", "expira_em": 3600 }
    // ============================================================

    // Configura CORS e carrega autenticacao
    require_once(__DIR__ . '/auth.php');
    configurarCORS();

    // Apenas aceita requisicoes POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['erro' => 'Metodo nao permitido. Use POST.']);
        exit;
    }

    // Le os dados enviados (aceita JSON no body ou POST tradicional)
    $input = file_get_contents('php://input');
    $dados = json_decode($input, true);
    if (!$dados) {
        $dados = $_POST;
    }

    // Verifica se os campos foram enviados
    if (empty($dados['usuario']) || empty($dados['senha'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Campos obrigatorios: usuario e senha']);
        exit;
    }

    $usuario = $dados['usuario'];
    $senha   = $dados['senha'];

    // -------------------------------------------------------
    //  CONEXAO COM O BANCO DE DADOS
    // -------------------------------------------------------
    require_once(__DIR__ . '/dbConnect.php');

    // -------------------------------------------------------
    //  BUSCAR USUARIO NO BANCO
    //  Usa prepared statement para proteger contra SQL Injection
    // -------------------------------------------------------
    $query = 'SELECT id, usuario, senha, nome_completo, ativo 
              FROM usuarios 
              WHERE usuario = ?';

    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 's', $usuario);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    // Se nao encontrou o usuario
    if (!$row) {
        http_response_code(401);
        echo json_encode(['erro' => 'Credenciais invalidas']);
        mysqli_close($conn);
        exit;
    }

    // -------------------------------------------------------
    //  VERIFICAR SE O USUARIO ESTA ATIVO
    // -------------------------------------------------------
    if (!$row['ativo']) {
        http_response_code(403);
        echo json_encode(['erro' => 'Usuario desativado. Contate o administrador.']);
        mysqli_close($conn);
        exit;
    }

    // -------------------------------------------------------
    //  VERIFICAR A SENHA
    //  password_verify() compara a senha digitada com o hash armazenado
    //  NUNCA use == ou strcmp() para comparar senhas!
    // -------------------------------------------------------
    if (!password_verify($senha, $row['senha'])) {
        http_response_code(401);
        echo json_encode(['erro' => 'Credenciais invalidas']);
        mysqli_close($conn);
        exit;
    }

    // -------------------------------------------------------
    //  GERACAO DO TOKEN JWT
    // -------------------------------------------------------
    $token = gerarToken($row['usuario']);

    mysqli_close($conn);

    // Retorna o token para o FrontEnd
    echo json_encode([
        'mensagem'     => 'Login realizado com sucesso',
        'token'        => $token,
        'expira_em'    => 3600,
        'usuario'      => $row['usuario'],
        'nome'         => $row['nome_completo']
    ]);
?>
