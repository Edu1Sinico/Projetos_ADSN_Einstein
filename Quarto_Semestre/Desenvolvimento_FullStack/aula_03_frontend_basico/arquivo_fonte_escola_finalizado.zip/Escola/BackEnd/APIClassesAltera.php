<?php
    // ============================================================
    //  API: ALTERAR CLASSE
    // ============================================================
    //  Altera os dados de uma classe existente.
    //  Protegida por JWT - necessario token valido.
    //
    //  PARAMETROS: id, nome, idcurso (via POST)
    // ============================================================

    // Valida o token JWT
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco
    require_once(__DIR__ . '/dbConnect.php');

    // Verifica se os parametros foram enviados
    if (empty($_POST['id']) || empty($_POST['nome']) || empty($_POST['idcurso'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Parametros obrigatorios: id, nome e idcurso']);
        mysqli_close($conn);
        exit;
    }

    $id       = (int) $_POST['id'];
    $nome     = $_POST['nome'];
    $id_curso = (int) $_POST['idcurso'];

    // Prepara a query com placeholders '?'
    // 'sii' = string, integer, integer
    $query = 'UPDATE classes SET nome = ?, curso_id = ? WHERE id = ?';
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'sii', $nome, $id_curso, $id);

    // Executa a atualizacao
    $result = mysqli_stmt_execute($stmt);

    $response = [];

    if ($result) {
        $response['alterou'] = (mysqli_affected_rows($conn) > 0);
    } else {
        http_response_code(500);
        $response['erro'] = 'Erro na execucao do update';
    }

    mysqli_close($conn);
    echo json_encode($response);
?>
