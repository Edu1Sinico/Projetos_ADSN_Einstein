<?php
    // ============================================================
    //  API: LISTAR TODAS AS CLASSES
    // ============================================================
    //  Retorna a lista de classes com o nome do curso associado.
    //  Protegida por JWT - necessario token valido.
    // ============================================================

    // Valida o token JWT
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco
    require_once(__DIR__ . '/dbConnect.php');

    // Query com JOIN para trazer o nome do curso junto
    $query = 'SELECT classes.id,
                     classes.nome,
                     cursos.nome AS curso
              FROM classes
              INNER JOIN cursos ON classes.curso_id = cursos.id
              ORDER BY curso, nome';

    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    mysqli_stmt_bind_result($stmt, $id, $nome, $curso);

    $response = [];

    if (mysqli_stmt_num_rows($stmt) > 0) {
        while (mysqli_stmt_fetch($stmt)) {
            $response[] = [
                'id'    => $id,
                'nome'  => $nome,
                'curso' => $curso
            ];
        }
    }

    mysqli_close($conn);
    echo json_encode($response);
?>
