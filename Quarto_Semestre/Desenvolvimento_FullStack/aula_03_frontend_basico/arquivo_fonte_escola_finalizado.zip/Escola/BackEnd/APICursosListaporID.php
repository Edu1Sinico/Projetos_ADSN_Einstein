<?php
    // ============================================================
    //  API: LISTAR CURSO POR ID
    // ============================================================
    //  Retorna um curso especifico pelo seu ID.
    //  Protegida por JWT - necessario token valido.
    //
    //  PARAMETROS: id (via POST)
    // ============================================================

    // Valida o token JWT
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco
    require_once(__DIR__ . '/dbConnect.php');

    // Verifica se o parametro 'id' foi enviado
    if (empty($_POST['id'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Parametro obrigatorio: id']);
        mysqli_close($conn);
        exit;
    }

    $idCurso = (int) $_POST['id'];

    // Prepara a query com placeholder '?'
    // 'i' = integer (indica que o parametro e um numero inteiro)
    $query = 'SELECT id, nome FROM cursos WHERE id = ?';
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $idCurso);

    // Executa e armazena resultados
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    mysqli_stmt_bind_result($stmt, $id, $nome);

    $response = [];

    if (mysqli_stmt_num_rows($stmt) > 0) {
        while (mysqli_stmt_fetch($stmt)) {
            $response[] = [
                'id'   => $id,
                'nome' => $nome
            ];
        }
    } else {
        $response['warning'] = 'Registro nao encontrado';
    }

    mysqli_close($conn);
    echo json_encode($response);
?>
