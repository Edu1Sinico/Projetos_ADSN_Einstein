<?php
    // ============================================================
    //  API: LISTAR TODOS OS CURSOS
    // ============================================================
    //  Retorna a lista completa de cursos cadastrados.
    //  Protegida por JWT - necessario token valido.
    // ============================================================

    // Valida o token JWT (se invalido, retorna 401 e para)
    require_once(__DIR__ . '/auth.php');
    $payload = validarToken();

    // Conecta ao banco de dados
    require_once(__DIR__ . '/dbConnect.php');

    // Prepara a query usando prepared statement (PROTEGE contra SQL Injection)
    // O '?' e um placeholder que sera substituido pelo valor de forma segura
    $query = 'SELECT id, nome FROM cursos';
    $stmt = mysqli_prepare($conn, $query);

    // Executa a query (sem parametros pois nao ha WHERE)
    mysqli_stmt_execute($stmt);

    // Armazena os resultados em memoria
    mysqli_stmt_store_result($stmt);

    // Associa as colunas da query a variaveis PHP
    mysqli_stmt_bind_result($stmt, $id, $nome);

    // Monta o array de resposta
    $response = [];

    // Se houver registros, adiciona ao array
    if (mysqli_stmt_num_rows($stmt) > 0) {
        while (mysqli_stmt_fetch($stmt)) {
            $response[] = [
                'id'   => $id,
                'nome' => $nome
            ];
        }
    }

    // Fecha a conexao com o banco
    mysqli_close($conn);

    // Retorna o array em formato JSON
    echo json_encode($response);
?>
