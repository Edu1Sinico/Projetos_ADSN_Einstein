<?php
    // ============================================================
    //  CONFIGURACAO DO BACKEND
    // ============================================================
    //  Este arquivo contem as configuracoes de seguranca do sistema.
    //  NUNCA versione este arquivo com valores reais em producao!
    // ============================================================

    // --- Chave secreta para assinatura JWT ---
    // Em producao, deve ser uma string longa e aleatoria armazenada
    // em variavel de ambiente, NUNCA no codigo-fonte.
    $jwtSecret = 'Escola@2024_SegurancaJWT';

    // --- Algoritmo de assinatura JWT ---
    // HS256 = HMAC com SHA-256 (simetrico, usa mesma chave para assinar e verificar)
    $jwtAlgorithm = 'HS256';

    // --- Tempo de vida do token JWT (em segundos) ---
    // 3600 segundos = 1 hora
    $jwtExpiresIn = 3600;
?>
