<?php
    require_once(__DIR__ . '/auth.php');
    verificarLogin();

    // Busca os dados da classe para confirmar exclusao
    $classe = chamarAPI('APIClassesListaporID.php', ['id' => $_GET['id']]);

    $nome = '';
    $curso = '';
    if ($classe && count($classe) > 0 && isset($classe[0])) {
        $nome  = $classe[0]['nome'];
        $curso = $classe[0]['curso'];
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>Exclusao de Classes</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background-color: #f0f2f5; }
            .container { max-width: 500px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
            h1 { color: #f44336; }
            .info { background-color: #fff3e0; border: 1px solid #ffe0b2; padding: 15px; border-radius: 4px; margin: 20px 0; text-align: left; }
            .info p { margin: 5px 0; color: #333; }
            .botoes { margin-top: 25px; }
            .btn { display: inline-block; padding: 10px 20px; border-radius: 4px; text-decoration: none; font-size: 14px; border: none; cursor: pointer; }
            .btn-confirmar { background-color: #f44336; color: white; }
            .btn-cancelar { background-color: #607D8B; color: white; margin-left: 10px; text-decoration: none; padding: 10px 20px; border-radius: 4px; display: inline-block; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Confirmar Exclusao</h1>
            <p>Tem certeza que deseja excluir esta classe?</p>

            <div class="info">
                <p><strong>Nome:</strong> <?php echo htmlspecialchars($nome); ?></p>
                <p><strong>Curso:</strong> <?php echo htmlspecialchars($curso); ?></p>
            </div>

            <form action="GravaExcluiClasse.php" method="post" class="botoes">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($_GET['id']); ?>">
                <input type="submit" class="btn btn-confirmar" value="Sim, Excluir">
                <a href="ListaClasses.php" class="btn-cancelar">Cancelar</a>
            </form>
        </div>
    </body>
</html>
