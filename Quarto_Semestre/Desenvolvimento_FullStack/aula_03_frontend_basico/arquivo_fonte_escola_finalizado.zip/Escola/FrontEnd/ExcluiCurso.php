<?php
    require_once(__DIR__ . '/auth.php');
    verificarLogin();

    // Busca os dados do curso para confirmar exclusao
    $curso = chamarAPI('APICursosListaporID.php', ['id' => $_GET['id']]);

    $nome = '';
    if ($curso && count($curso) > 0 && isset($curso[0])) {
        $nome = $curso[0]['nome'];
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>Exclusao de Cursos</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background-color: #f0f2f5; }
            .container { max-width: 500px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
            h1 { color: #f44336; }
            .info { background-color: #fff3e0; border: 1px solid #ffe0b2; padding: 15px; border-radius: 4px; margin: 20px 0; text-align: left; }
            .info p { margin: 5px 0; color: #333; }
            .alerta { background-color: #ffebee; border: 1px solid #ffcdd2; padding: 10px; border-radius: 4px; color: #c62828; margin-bottom: 15px; }
            .botoes { margin-top: 25px; }
            .btn { display: inline-block; padding: 10px 20px; border-radius: 4px; text-decoration: none; font-size: 14px; border: none; cursor: pointer; }
            .btn-confirmar { background-color: #f44336; color: white; }
            .btn-cancelar { background-color: #607D8B; color: white; margin-left: 10px; text-decoration: none; padding: 10px 20px; border-radius: 4px; display: inline-block; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Confirmar Exclusao</h1>
            <p>Tem certeza que deseja excluir este curso?</p>

            <div class="alerta">Atencao: Classes vinculadas a este curso podem ser afetadas!</div>

            <div class="info">
                <p><strong>Nome do Curso:</strong> <?php echo htmlspecialchars($nome); ?></p>
            </div>

            <form action="GravaExcluiCurso.php" method="post" class="botoes">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($_GET['id']); ?>">
                <input type="submit" class="btn btn-confirmar" value="Sim, Excluir">
                <a href="ListaCursos.php" class="btn-cancelar">Cancelar</a>
            </form>
        </div>
    </body>
</html>
