<?php
    // ============================================================
    //  CONFIGURACAO DO FRONTEND
    // ============================================================
    //  Este arquivo contem as configuracoes de conexao
    //  entre o FrontEnd e o BackEnd (API).
    // ============================================================

    // URL base do servidor BackEnd
    $servidor = 'localhost';

    // URL completa da API (ajuste conforme necessario)
    $apiBase = "http://$servidor/Escola/BackEnd";
?>
