<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>Sistema Escolar</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background-color: #f0f2f5; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #333; text-align: center; }
            .menu { display: flex; flex-direction: column; gap: 15px; margin-top: 30px; }
            .menu a { display: block; padding: 15px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px; font-size: 18px; text-align: center; }
            .menu a:hover { background-color: #45a049; }
            .menu a.cursos { background-color: #2196F3; }
            .menu a.cursos:hover { background-color: #1976D2; }
            .header { text-align: right; margin-bottom: 20px; color: #888; font-size: 14px; }
            .header a { color: #c33; text-decoration: none; }
        </style>
    </head>
    <body>
        <?php
            require_once(__DIR__ . '/auth.php');
            verificarLogin();
        ?>
        <div class="container">
            <div class="header">
                Logado como: <?php echo htmlspecialchars(obterUsuario()); ?>
                | <a href="Logout.php">Sair</a>
            </div>
            <h1>Menu Principal</h1>
            <div class="menu">
                <a href="ListaCursos.php" class="cursos">Cursos</a>
                <a href="ListaClasses.php">Classes</a>
            </div>
        </div>
    </body>
</html>
