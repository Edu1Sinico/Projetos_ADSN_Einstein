<?php
    require_once(__DIR__ . '/auth.php');
    verificarLogin();

    // Executa a exclusao via API
    $resultado = chamarAPI('APICursosDeleta.php', [
        'id' => $_POST['id']
    ]);
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>Exclusao de Cursos</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background-color: #f0f2f5; }
            .container { max-width: 500px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
            .sucesso { color: #4CAF50; font-size: 18px; font-weight: bold; }
            .erro { color: #f44336; font-size: 18px; font-weight: bold; }
            .btn { display: inline-block; padding: 10px 20px; border-radius: 4px; text-decoration: none; font-size: 14px; margin-top: 20px; }
            .btn-lista { background-color: #2196F3; color: white; }
        </style>
    </head>
    <body>
        <div class="container">
            <?php if ($resultado && isset($resultado['apagado']) && $resultado['apagado']): ?>
                <p class="sucesso">Curso excluido com sucesso!</p>
            <?php else: ?>
                <p class="erro">Erro na exclusao do curso.</p>
            <?php endif; ?>

            <a href="ListaCursos.php" class="btn btn-lista">Voltar a lista</a>
        </div>
    </body>
</html>
