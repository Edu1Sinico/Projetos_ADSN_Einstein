<?php
    // ============================================================
    //  GERENCIAMENTO DE AUTENTICACAO (FrontEnd)
    // ============================================================
    //  Este arquivo gerencia a sessao do usuario no FrontEnd.
    //  Responsabilidades:
    //  1. Iniciar sessao PHP
    //  2. Fazer login via API e salvar o token JWT
    //  3. Verificar se o usuario esta logado
    //  4. Fornecer o token para chamadas a API
    //  5. Fazer logout (destruir sessao)
    // ============================================================

    // SEMPRE inicie a sessao no inicio de cada pagina!
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Inclui a configuracao
    require_once(__DIR__ . '/Config.php');

    /**
     * Faz login via API e salva o token na sessao.
     *
     * @param string $usuario Nome do usuario
     * @param string $senha   Senha do usuario
     * @return array ['sucesso' => bool, 'erro' => string|null]
     */
    function fazerLogin(string $usuario, string $senha): array
    {
        global $apiBase;

        // Monta os dados para enviar a API de login
        $postdata = http_build_query([
            'usuario' => $usuario,
            'senha'   => $senha
        ]);

        // Configura a requisicao HTTP usando file_get_contents
        $opts = [
            'http' => [
                'method'  => 'POST',
                'header'  => 'Content-type: application/x-www-form-urlencoded',
                'content' => $postdata
            ]
        ];

        $context = stream_context_create($opts);
        $result = file_get_contents("$apiBase/APILogin.php", false, $context);

        // Decodifica a resposta JSON
        $response = json_decode($result, true);

        // Se login bem-sucedido, salva o token na sessao
        if (isset($response['token'])) {
            $_SESSION['token']      = $response['token'];
            $_SESSION['usuario']    = $response['usuario'];
            $_SESSION['nome']       = $response['nome'] ?? $response['usuario'];
            $_SESSION['login_time'] = time();
            return ['sucesso' => true, 'erro' => null];
        }

        // Se falhou, retorna a mensagem de erro
        $erro = $response['erro'] ?? 'Erro desconhecido no login';
        return ['sucesso' => false, 'erro' => $erro];
    }

    /**
     * Verifica se o usuario esta logado.
     * Se nao estiver, redireciona para a pagina de login.
     */
    function verificarLogin(): void
    {
        if (!isset($_SESSION['token'])) {
            header('Location: Login.php');
            exit;
        }
    }

    /**
     * Retorna o token JWT salvo na sessao.
     *
     * @return string Token JWT
     */
    function obterToken(): string
    {
        return $_SESSION['token'] ?? '';
    }

    /**
     * Retorna o nome do usuario logado.
     *
     * @return string Nome do usuario
     */
    function obterUsuario(): string
    {
        return $_SESSION['nome'] ?? $_SESSION['usuario'] ?? '';
    }

    /**
     * Faz logout - destrui a sessao e redireciona para o login.
     */
    function fazerLogout(): void
    {
        session_destroy();
        header('Location: Login.php');
        exit;
    }

    /**
     * Chama uma API do BackEnd com autenticacao JWT.
     *
     * Usa file_get_contents + stream_context_create.
     * O header Authorization e enviado corretamente porque o BackEnd
     * le via getallheaders() quando $_SERVER['HTTP_AUTHORIZATION'] nao existe.
     *
     * @param string $endpoint Nome do arquivo PHP da API (ex: 'APICursosListaTodos.php')
     * @param array  $params   Parametros a enviar via POST
     * @return array|null Dados decodificados do JSON, ou null em caso de erro
     */
    function chamarAPI(string $endpoint, array $params = []): ?array
    {
        global $apiBase;

        // Codifica os parametros para envio via POST
        $postdata = http_build_query($params);

        // Monta as opcoes HTTP com o header de autorizacao
        $opts = [
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n" .
                              "Authorization: Bearer " . obterToken(),
                'content' => $postdata
            ]
        ];

        $context = stream_context_create($opts);

        // Chama a API usando file_get_contents
        $result = file_get_contents("$apiBase/$endpoint", false, $context);

        if ($result === false) {
            return null;
        }

        return json_decode($result, true);
    }
?>
