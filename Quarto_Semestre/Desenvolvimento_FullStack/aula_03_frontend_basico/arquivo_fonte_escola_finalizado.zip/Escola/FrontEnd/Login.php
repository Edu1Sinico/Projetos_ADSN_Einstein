<?php
    // Inicia a sessao
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Se ja esta logado, redireciona para o menu
    if (isset($_SESSION['token'])) {
        header('Location: index.php');
        exit;
    }

    // Processa o formulario de login
    $erro = null;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        require_once(__DIR__ . '/auth.php');
        $usuario = $_POST['usuario'] ?? '';
        $senha   = $_POST['senha'] ?? '';

        $resultado = fazerLogin($usuario, $senha);

        if ($resultado['sucesso']) {
            header('Location: index.php');
            exit;
        } else {
            $erro = $resultado['erro'];
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>Login - Sistema Escolar</title>
        <style>
            body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: #f0f2f5; }
            .login-box { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 350px; }
            h1 { text-align: center; color: #333; margin-bottom: 30px; }
            label { display: block; margin-bottom: 5px; color: #555; font-weight: bold; }
            input[type="text"], input[type="password"] { width: 100%; padding: 10px; margin-bottom: 20px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; font-size: 14px; }
            input[type="submit"] { width: 100%; padding: 12px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
            input[type="submit"]:hover { background-color: #45a049; }
            .erro { background-color: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px; margin-bottom: 20px; text-align: center; }

        </style>
    </head>
    <body>
        <div class="login-box">
            <h1>Sistema Escolar</h1>

            <?php if ($erro): ?>
                <div class="erro"><?php echo htmlspecialchars($erro); ?></div>
            <?php endif; ?>

            <form method="post" action="Login.php">
                <label for="usuario">Usuario:</label>
                <input type="text" id="usuario" name="usuario" required autofocus>

                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>

                <input type="submit" value="Entrar">
            </form>

        </div>
    </body>
</html>
