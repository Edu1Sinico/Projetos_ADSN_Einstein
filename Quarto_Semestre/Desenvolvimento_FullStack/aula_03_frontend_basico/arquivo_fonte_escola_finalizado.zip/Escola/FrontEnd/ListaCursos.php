<?php
    require_once(__DIR__ . '/auth.php');
    verificarLogin();

    // Chama a API para listar todos os cursos
    $jsonObj = chamarAPI('APICursosListaTodos.php');
    if (!$jsonObj) $jsonObj = [];
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>Lista de Cursos</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background-color: #f0f2f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #333; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #ddd; }
            th { background-color: #2196F3; color: white; }
            tr:hover { background-color: #f5f5f5; }
            .btn { display: inline-block; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 13px; margin-left: 5px; }
            .btn-editar { background-color: #FFC107; color: #333; }
            .btn-excluir { background-color: #f44336; color: white; }
            .btn-novo { display: inline-block; padding: 10px 20px; background-color: #2196F3; color: white; text-decoration: none; border-radius: 4px; margin-top: 20px; }
            .btn-voltar { display: inline-block; padding: 10px 20px; background-color: #607D8B; color: white; text-decoration: none; border-radius: 4px; margin-top: 20px; margin-left: 10px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Lista de Cursos</h1>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Nome do Curso</th>
                    <th>Acoes</th>
                </tr>
                <?php
                    foreach ($jsonObj as $curso) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($curso['id']) . "</td>";
                        echo "<td>" . htmlspecialchars($curso['nome']) . "</td>";
                        echo "<td>";
                        echo "<a class='btn btn-editar' href='AlteraCurso.php?id=" . htmlspecialchars($curso['id']) . "'>Alterar</a>";
                        echo "<a class='btn btn-excluir' href='ExcluiCurso.php?id=" . htmlspecialchars($curso['id']) . "'>Excluir</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                ?>
            </table>
            <a href="IncluiCurso.php" class="btn-novo">Incluir Curso</a>
            <a href="index.php" class="btn-voltar">Voltar</a>
        </div>
    </body>
</html>
