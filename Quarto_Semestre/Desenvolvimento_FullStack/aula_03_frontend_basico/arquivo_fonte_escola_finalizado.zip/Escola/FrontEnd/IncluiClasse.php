<?php
    require_once(__DIR__ . '/auth.php');
    verificarLogin();

    // Lista os cursos para exibir no combo
    $cursos = chamarAPI('APICursosListaTodos.php');
    if (!$cursos) $cursos = [];
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>Inclusao de Classes</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background-color: #f0f2f5; }
            .container { max-width: 500px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #333; }
            label { display: block; margin-bottom: 5px; color: #555; font-weight: bold; margin-top: 15px; }
            input[type="text"], select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; font-size: 14px; }
            .botoes { margin-top: 25px; }
            .btn { display: inline-block; padding: 10px 20px; border-radius: 4px; text-decoration: none; font-size: 14px; border: none; cursor: pointer; }
            .btn-salvar { background-color: #4CAF50; color: white; }
            .btn-limpar { background-color: #FFC107; color: #333; margin-left: 10px; }
            .btn-voltar { background-color: #607D8B; color: white; margin-left: 10px; text-decoration: none; padding: 10px 20px; border-radius: 4px; display: inline-block; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Incluir Classe</h1>
            <form action="GravaNovaClasse.php" method="post">
                <label>Descricao:</label>
                <input type="text" name="nome" required>

                <label>Curso:</label>
                <select name="id_curso" required>
                    <option value="">Selecione um curso...</option>
                    <?php
                        foreach ($cursos as $curso) {
                            echo "<option value='" . htmlspecialchars($curso['id']) . "'>";
                            echo htmlspecialchars($curso['nome']);
                            echo "</option>";
                        }
                    ?>
                </select>

                <div class="botoes">
                    <input type="submit" class="btn btn-salvar" value="Incluir">
                    <input type="reset" class="btn btn-limpar" value="Limpar">
                    <a href="ListaClasses.php" class="btn-voltar">Voltar</a>
                </div>
            </form>
        </div>
    </body>
</html>
